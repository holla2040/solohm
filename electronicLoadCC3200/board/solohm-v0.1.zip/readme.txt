This information, board files, assembly instructions and bill of
materials is company confidental.
Not for distribution.

board
    solohm

version
    0.1
    150101

description
    Top layer:                  pcbname.GTL
    Bottom layer:               pcbname.GBL
    Solder Stop Mask top:       pcbname.GTS
    Solder Stop Mask Bottom:    pcbname.GBS
    Silk Top:                   pcbname.GTO
    Silk Bottom:                pcbname.GBO
    NC Drill:                   pcbname.TXT

    drd drill data
    dri drill info
    gpi gerber info

fudicials at
    0.25,0.1
    3.6,3.8

layer stack up sequence
    top     x.GTL
    bottom  x.GBL

contact info
    Craig Hollabaugh
    970 690 4911
    craig@hollabaugh.com


